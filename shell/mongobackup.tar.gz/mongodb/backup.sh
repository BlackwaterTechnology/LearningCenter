#!/bin/bash
#检查环境
if [ -e $(dirname "$0")/mongo.conf ]; then
    source $(dirname "$0")/mongo.conf
else
    echo "配置文件不存在，请检查配置"
    exit 2
fi

if [ ! -e $(dirname "$0")/scripts.sh ]; then
    echo "备份脚本不存在，请检查脚本"
    exit 2
fi

if [ ! -e $(dirname "$0")/${LOGPATH} ]
then
   echo "日志目录不存在，请先创建"
   exit 2
fi

if [ ! -e ${OUTPATH} ]
then
   echo "备份输出目录不存在，请先创建" >1&2
   exit 2
fi

/usr/bin/which docker 1>/dev/null 2>/dev/null
if [ $? -gt 0 ]; then
  echo "docker不存在，备份需要docker执行，请准备docker环境" >1&2
fi
#定义变量
LogFile=$(dirname "$0")/${LOGPATH}/back`date +"%Y%m%d"`.log
backup_Ymd=`date +%Y%m%d`                       
backup_ago=`date -d "${MAX_BACKUPS} days ago" +%Y%m%d`      
backup_dir=${OUTPATH}/$backup_Ymd         
welcome_msg="Welcome to use mongo backup tools!"
expire_backup_delete=ON


echo "$welcome_msg" >> $LogFile

echo "database backup start..." >> $LogFile
#/usr/bin/mongodump -h$mongo_host --username root --password '!QAZxsw2root' --authenticationDatabase admin --gzip -o $backup_dir  >> $LogFile 2>&1 &
docker run --rm --user=root -d -e "DATE=${backup_Ymd}" -v $(dirname "$0")/scripts.sh:/scripts.sh -v $(dirname "$0")/mongo.conf:/mongo.conf -v ${OUTPATH}:${OUTPATH} --entrypoint /bin/bash mongo:3.4 /scripts.sh  >> $LogFile

sleep 10
#上传云存储
if [ -e ${backup_Ymd} ]; then
#scp -r $(date +%Y%m%d) 172.16.40.18:/mnt/bak/wn/
  mc cp -r ${backup_Ymd} xtcloud/backup/mongodb/ >> $LogFile
  echo "上传云存储完成！！！" >> $LogFile
fi

flag=$(echo $?)
if [ $flag -eq "0" ]
  then
  echo "database  success backup" >> $LogFile
else
  echo "database  backup fail!" >> $LogFile
fi

if [ -e ${backup_ago} ];then
  rm -rf ${backup_ago}
  echo "已删除过期文件" >> $LogFile
else 
echo "Expire_backup_delete flag is OFF!" >> $LogFile
fi
echo "All database backup success! Think you!" >> $LogFile
exit
