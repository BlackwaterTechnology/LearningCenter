#bin/bash
#mongodump --host "rs0/172.16.43.71:27017,172.16.43.72:27018,172.16.43.73:27019" --username root --password '!QAZxsw2root' --authenticationDatabase admin --gzip --out /opt/$(date +%Y%m%d%H%M)
source /mongo.conf
mongodump --host ${HOST} --username ${USERNAME} --password ${PASSWORD} --authenticationDatabase admin --gzip --out ${OUTPATH}/${DATE}
